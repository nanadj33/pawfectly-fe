package com.example.pawfectly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
