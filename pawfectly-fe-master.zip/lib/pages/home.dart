import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark.copyWith(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));

    return Scaffold(
      backgroundColor: Color(0xffFCF2F1),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        leading: Icon(
          Icons.menu,
          color: Color(0xff704520),
          size: 30,
        ),
        title: SvgPicture.asset(
          'assets/images/logo1.svg',
          width: 110,
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.notifications,
              color: Color(0xff704520),
              size: 30,
            ),
          )
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 18),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Hi,",
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w200,
                              fontSize: 24,
                              color: Color(0xff704520),
                            ),
                          ),
                          Text(
                            "Regina!",
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w900,
                              fontSize: 36.0,
                              color: Color(0xff704520),
                              height: 0.8,
                            ).apply(fontWeightDelta: 2),
                          ),
                        ],
                      ),
                      SvgPicture.asset('assets/images/profile.svg', width: 98,),
                    ],
                  ),
                ),

                SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(
                    color: Color(0xffFDB384),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.all(25),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              SvgPicture.asset('assets/images/clinicfinder.svg', width: 68,),
                              SizedBox(height: 6),
                              Text(
                                'Clinic Finder',
                                style: GoogleFonts.poppins(
                                  color: Color(0xff704520),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              SvgPicture.asset('assets/images/offlineconsult.svg', width: 68,),
                              SizedBox(height: 6),
                              Text(
                                'Offline Consultation',
                                style: GoogleFonts.poppins(
                                  color: Color(0xff704520),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              SvgPicture.asset('assets/images/petreport.svg', width: 68,),
                              SizedBox(height: 6),
                              Text(
                                'Pet Report',
                                style: GoogleFonts.poppins(
                                  color: Color(0xff704520),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                      SizedBox(height: 20,),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 255, 255, 255),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              width: 300,
                              height: 100,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Shower Day',
                                    style: GoogleFonts.poppins(
                                      fontSize: 20,
                                    ),
                                  ),
                                  Text(
                                    '2 days left',
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      height: 1,
                                      fontWeight: FontWeight.w200,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(width: 16),
                            Container(
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 255, 255, 255),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              width: 300,
                              height: 100,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Shower Day',
                                    style: GoogleFonts.poppins(
                                      fontSize: 20,
                                    ),
                                  ),
                                  Text(
                                    '2 days left',
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      height: 1,
                                      fontWeight: FontWeight.w200,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 14),
                Container(
                  decoration: BoxDecoration(
                    color: Color(0xffF6CDC7),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 14),
                  padding: const EdgeInsets.all(25),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'My Pets',
                            style: GoogleFonts.poppins(
                              color: Color(0xffCC5946),
                              fontWeight: FontWeight.w700,
                              fontSize: 20,
                            ),
                          ),
                          SvgPicture.asset('assets/images/plus.svg', width: 28,)
                        ],
                      ),
                      SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Image.asset('assets/images/mushroom.png'),
                              SizedBox(height: 6),
                              Text(
                                'Mushroom',
                                style: GoogleFonts.poppins(
                                  color: Color(0xffCC5946),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              Image.asset('assets/images/molly.png'),
                              SizedBox(height: 6),
                              Text(
                                'Molly',
                                style: GoogleFonts.poppins(
                                  color: Color(0xffCC5946),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              Image.asset('assets/images/corgi.png'),
                              SizedBox(height: 6),
                              Text(
                                'Corgi',
                                style: GoogleFonts.poppins(
                                  color: Color(0xffCC5946),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 38),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Trending Topic!',
                        style: GoogleFonts.poppins(
                          fontSize: 26,
                          color: Color(0xff403D2F),
                        ),
                      ),
                      Container(
                        child: Row(
                          children: [
                            Text('More Discussion',
                            style: GoogleFonts.poppins(
                              color: Color(0xffAE918D),
                            ),
                            ),
                            Icon(
                              Icons.chevron_right,
                              color: Color(0xffAE918D),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(14, 163, 111, 106),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      )
                    ],
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  SvgPicture.asset('assets/images/wawan.svg', width: 50,),
                                  Container(
                                    margin: EdgeInsets.only(left:14),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Wawan',
                                          style: GoogleFonts.poppins(
                                            fontSize: 22,
                                          ),
                                        ),
                                        Text(
                                          '20-08-2023 08:00',
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.bookmark,
                              size: 36,
                              color: Color(0xffE0BAB5),
                            )
                          ],
                        ),
                      ),
                      Text(
                        'Nggak sengaja makan makanan kucing!',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          height: 1.8,
                        ),
                      ),
                      SizedBox(height: 3,),
                      Text(
                        'Aduh... gimana ya tadi tuh kucing aku lagi makan di sebelah ...',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 18,),
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.favorite,
                                    size: 20,
                                    color: Color(0xffCC5946),
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    '100 Likes',
                                    style: GoogleFonts.poppins(
                                      fontSize: 13,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Text(
                              'Read more',
                              style: GoogleFonts.poppins(
                                fontStyle: FontStyle.italic,
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),

                SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(14, 163, 111, 106),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      )
                    ],
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  SvgPicture.asset('assets/images/risa.svg', width: 50,),
                                  Container(
                                    margin: EdgeInsets.only(left:14),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Risa',
                                          style: GoogleFonts.poppins(
                                            fontSize: 22,
                                          ),
                                        ),
                                        Text(
                                          '18-12-2023 08:00',
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.bookmark,
                              size: 36,
                              color: Color.fromARGB(65, 224, 186, 181),
                            )
                          ],
                        ),
                      ),
                      Text(
                        'Kucing aku suka banget catnip ini <3',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          height: 1.8,
                        ),
                      ),
                      SizedBox(height: 3,),
                      Text(
                        'Aduh... gimana ya tadi tuh kucing aku lagi makan di sebelah ...',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 18,),
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.favorite,
                                    size: 20,
                                    color: Color(0xffCC5946),
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    '100 Likes',
                                    style: GoogleFonts.poppins(
                                      fontSize: 13,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Text(
                              'Read more',
                              style: GoogleFonts.poppins(
                                fontStyle: FontStyle.italic,
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),

                SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(14, 163, 111, 106),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      )
                    ],
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  SvgPicture.asset('assets/images/andi.svg', width: 50,),
                                  Container(
                                    margin: EdgeInsets.only(left:14),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Andi',
                                          style: GoogleFonts.poppins(
                                            fontSize: 22,
                                          ),
                                        ),
                                        Text(
                                          '20-08-2023 08:00',
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.bookmark,
                              size: 36,
                              color: Color(0xffE0BAB5),
                            )
                          ],
                        ),
                      ),
                      Text(
                        'Nggak sengaja makan makanan kucing!',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          height: 1.8,
                        ),
                      ),
                      SizedBox(height: 3,),
                      Text(
                        'Aduh... gimana ya tadi tuh kucing aku lagi makan di sebelah ...',
                                                style: GoogleFonts.poppins(
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 18,),
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.favorite,
                                    size: 20,
                                    color: Color(0xffCC5946),
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    '100 Likes',
                                    style: GoogleFonts.poppins(
                                      fontSize: 13,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Text(
                              'Read more',
                              style: GoogleFonts.poppins(
                                fontStyle: FontStyle.italic,
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),

                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'More discussion',
                        style: GoogleFonts.poppins(
                          color: Color(0xffE0BAB5),
                          fontSize: 18,
                        ),
                      ),
                      Icon(
                        Icons.chevron_right,
                        color: Color(0xffE0BAB5),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 70,)
              ],
            ),
          ),
          Positioned(
            bottom: 10,
            right: 10,
            child: SvgPicture.asset(
              'assets/images/onlineconsult.svg',
              width: 200,
            ),
          ),
        ],
      ),
    );
  }
}

