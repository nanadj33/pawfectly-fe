package com.example.signpaw

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
